DigiRise Cloudflare AI Image Generator

Files:
- worker.js
- wrangler.jsonc

This Worker uses Cloudflare Workers AI with:
@cf/black-forest-labs/flux-1-schnell

After deployment, copy the Worker URL and put it into
image-generator.html:

const WORKER_URL = "YOUR_CLOUDFLARE_WORKER_URL";

Then the website sends POST requests to:
WORKER_URL + "/generate"

Important:
Workers AI availability and billing/limits depend on the Cloudflare account/plan.
